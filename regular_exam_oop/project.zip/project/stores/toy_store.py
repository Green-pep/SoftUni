from typing import List

from project.products.hobby_horse import HobbyHorse
from project.stores.base_store import BaseStore


class ToyStore(BaseStore):
    def __init__(self, name: str, location: str, capacity: int = 0):
        super().__init__(name, location, capacity)

    @property
    def store_type(self):
        type_of_store = "ToyStore"
        return type_of_store

