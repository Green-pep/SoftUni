from typing import List

from project.products.chair import Chair
from project.stores.base_store import BaseStore


class FurnitureStore(BaseStore):
    def __init__(self, name: str, location: str, capacity: int = 0):
        super().__init__(name, location, capacity)

    @property
    def store_type(self):
        type_of_store = "FurnitureStore"
        return type_of_store
